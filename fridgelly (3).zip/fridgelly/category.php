<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fridgelly";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Image mapping for each category
$imageMap = [
    "Malay" => "malay.jpg",
    "Thai" => "thai.png",
    "Chinese" => "chinese.png",
    "Indian" => "indian.png",
    "Korean" => "korean.png",
    "Japanese" => "japanese.png",
    "Italian" => "italian.png",
    "Mexican" => "mexican.png",
    "French" => "french.png",
    "Turkish" => "turkish.png",
    "Spanish" => "spanish.png",
    "British" => "english.png"
];

// Check if a category ID is provided
$cuisine_id = isset($_GET['id']) ? intval($_GET['id']) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php 
        if ($cuisine_id) {
            $result = $conn->query("SELECT name FROM cuisine WHERE cuisine_id = $cuisine_id");
            echo ($result && $result->num_rows > 0) ? $result->fetch_assoc()['name'] . " Recipes" : "Recipes";
        } else {
            echo "Browse Categories";
        }
        ?>
    </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fffaf5;
            margin: 0;
        }
        header {
            text-align: center;
            padding: 2rem;
            background-color: #ff7043;
            color: white;
        }
        .container {
            max-width: 1100px;
            margin: auto;
            padding: 20px;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }
        .card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.03);
        }
        .card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        .card h3 {
            margin: 0;
            padding: 10px;
            background: #ffe0b2;
            color: #4e342e;
        }
        a {
            text-decoration: none;
        }
        .recipe-card {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            text-align: center;
        }
    </style>
</head>
<body>

<header>
    <h1>
        <?php 
        if ($cuisine_id) {
            $result = $conn->query("SELECT name FROM cuisine WHERE cuisine_id = $cuisine_id");
            echo ($result && $result->num_rows > 0) ? $result->fetch_assoc()['name'] . " Recipe" : "Recipe";
        } else {
            echo "Browse Categories";
        }
        ?>
    </h1>
</header>

<div class="container">
    <?php
    if ($cuisine_id) {
        // Show recipes in the selected category
        $sqlRecipes = "SELECT title, time_needs, likes_count FROM recipe WHERE cuisine_id = $cuisine_id";
        $resultRecipes = $conn->query($sqlRecipes);

        if ($resultRecipes && $resultRecipes->num_rows > 0) {
            echo '<div class="grid">';
            while ($row = $resultRecipes->fetch_assoc()) {
                echo "<div class='recipe-card'>";
                echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
                echo "<p>Time: " . htmlspecialchars($row['time_needs']) . "</p>";
                echo "<p>Likes: " . $row['likes_count'] . "</p>";
                echo "</div>";
            }
            echo '</div>';
        } else {
            echo "<p>No recipes found in this category.</p>";
        }

    } else {
        // Show all categories
        $sqlCategories = "SELECT cuisine_id, name FROM cuisine";
        $resultCategories = $conn->query($sqlCategories);

        if ($resultCategories && $resultCategories->num_rows > 0) {
            echo '<div class="grid">';
            while ($row = $resultCategories->fetch_assoc()) {
                $categoryName = $row['name'];
                $imageFile = isset($imageMap[$categoryName]) ? $imageMap[$categoryName] : "default.jpg";
                $imagePath = "images/" . $imageFile;

                echo "<a href='category.php?id=" . $row['cuisine_id'] . "'>";
                echo "<div class='card'>";
                echo "<img src='" . $imagePath . "' alt='" . htmlspecialchars($categoryName) . "'>";
                echo "<h3>" . htmlspecialchars($categoryName) . "</h3>";
                echo "</div>";
                echo "</a>";
            }
            echo '</div>';
        } else {
            echo "<p>No categories found.</p>";
        }
    }
    ?>
</div>

</body>
</html>
<?php $conn->close(); ?>
