<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "fridgelly";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get cuisines
$cuisine_sql = "SELECT * FROM cuisine";
$cuisine_result = $conn->query($cuisine_sql);

// Get recipes
$recipe_sql = "SELECT r.recipe_id, r.title, r.time_needs, r.likes_count, c.name AS cuisine_name
               FROM recipe r
               JOIN cuisine c ON r.cuisine_id = c.cuisine_id";
$recipe_result = $conn->query($recipe_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin - Fridgelly</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            margin-top: 40px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f4f4f4;
        }
        a {
            text-decoration: none;
            color: blue;
        }
    </style>
</head>
<body>

<h1>Fridgelly Admin Panel</h1>

<!-- Cuisine Table -->
<h2>Cuisine List</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Actions</th>
    </tr>
<?php
if ($cuisine_result->num_rows > 0) {
    while($row = $cuisine_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['cuisine_id'] . "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>
                <a href='edit_cuisine.php?id=" . $row['cuisine_id'] . "'>Edit</a> | 
                <a href='delete_cuisine.php?id=" . $row['cuisine_id'] . "' onclick=\"return confirm('Delete this cuisine?')\">Delete</a>
              </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='3'>No cuisines found</td></tr>";
}
?>
</table>

<!-- Recipe Table -->
<h2>Recipe List</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Time Needs</th>
        <th>Cuisine</th>
        <th>Likes</th>
        <th>Actions</th>
    </tr>
<?php
if ($recipe_result->num_rows > 0) {
    while($row = $recipe_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['recipe_id'] . "</td>";
        echo "<td>" . $row['title'] . "</td>";
        echo "<td>" . $row['time_needs'] . "</td>";
        echo "<td>" . $row['cuisine_name'] . "</td>";
        echo "<td>" . $row['likes_count'] . "</td>";
        echo "<td>
                <a href='edit_recipe.php?id=" . $row['recipe_id'] . "'>Edit</a> | 
                <a href='delete_recipe.php?id=" . $row['recipe_id'] . "' onclick=\"return confirm('Delete this recipe?')\">Delete</a>
              </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No recipes found</td></tr>";
}
$conn->close();
?>
</table>

</body>
</html>
