<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "fridgelly";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$cuisine_id = isset($_GET['cuisine_id']) ? intval($_GET['cuisine_id']) : 0;

$sql = "SELECT r.title, r.time_needs, r.likes_count, c.name AS cuisine_name
        FROM recipe r
        JOIN cuisine c ON r.cuisine_id = c.cuisine_id
        WHERE r.cuisine_id = $cuisine_id";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Recipes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f8f8;
            padding: 20px;
        }
        .recipe-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        .recipe-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
            padding-bottom: 15px;
        }
        .recipe-card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }
        .recipe-card h3 {
            margin: 10px 0 5px;
        }
        .recipe-card p {
            margin: 5px 0;
            color: #555;
        }
    </style>
</head>
<body>

<h1>Recipes</h1>

<div class="recipe-grid">
<?php
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='recipe-card'>";
        echo "<img src='https://via.placeholder.com/300x180.png?text=" . urlencode($row['title']) . "' alt='" . htmlspecialchars($row['title']) . "'>";
        echo "<h3>" . htmlspecialchars($row['title']) . "</h3>";
        echo "<p>Cuisine: " . htmlspecialchars($row['cuisine_name']) . "</p>";
        echo "<p>Time: " . htmlspecialchars($row['time_needs']) . "</p>";
        echo "<p>Likes: ❤️ " . htmlspecialchars($row['likes_count']) . "</p>";
        echo "</div>";
    }
} else {
    echo "<p>No recipes found for this cuisine.</p>";
}
$conn->close();
?>
</div>

</body>
</html>
