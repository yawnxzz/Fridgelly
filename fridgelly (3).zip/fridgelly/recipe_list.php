<?php
// recipe_list.php

// Database connection
$servername = "localhost"; // Change if needed
$username = "root";        // Change if needed
$password = "";            // Change if needed
$dbname = "your_database"; // Change to your DB name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get category name from URL
if (isset($_GET['category'])) {
    $categoryName = $_GET['category'];

    // Get cuisine_id from cuisine table
    $stmtCuisine = $conn->prepare("SELECT cuisine_id FROM cuisine WHERE name = ?");
    $stmtCuisine->bind_param("s", $categoryName);
    $stmtCuisine->execute();
    $resultCuisine = $stmtCuisine->get_result();

    if ($resultCuisine->num_rows > 0) {
        $rowCuisine = $resultCuisine->fetch_assoc();
        $cuisineId = $rowCuisine['cuisine_id'];

        // Get recipes for this cuisine_id
        $stmtRecipes = $conn->prepare("SELECT recipe_id, title, time_needs, likes_count FROM recipes WHERE cuisine_id = ?");
        $stmtRecipes->bind_param("i", $cuisineId);
        $stmtRecipes->execute();
        $resultRecipes = $stmtRecipes->get_result();
    } else {
        echo "Category not found.";
        exit;
    }
} else {
    echo "No category selected.";
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Recipes - <?php echo htmlspecialchars($categoryName); ?></title>
    <link rel="stylesheet" href="styles.css"> <!-- Optional CSS -->
</head>
<body>
    <h1><?php echo htmlspecialchars($categoryName); ?> Recipes</h1>

    <?php
    if ($resultRecipes->num_rows > 0) {
        echo "<ul>";
        while ($row = $resultRecipes->fetch_assoc()) {
            echo "<li>";
            echo "<strong>" . htmlspecialchars($row['title']) . "</strong> - ";
            echo "Time: " . htmlspecialchars($row['time_needs']) . " mins - ";
            echo "Likes: " . htmlspecialchars($row['likes_count']);
            echo "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>No recipes found in this category.</p>";
    }
    ?>

</body>
</html>
