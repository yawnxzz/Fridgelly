<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "fridgelly";

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Cuisine data
    $cuisine_id = $_POST['cuisine_id'];
    $name = $_POST['name'];

    // Insert cuisine
    $sql = "INSERT INTO cuisine (cuisine_id, name) VALUES ('$cuisine_id', '$name')";
    if ($conn->query($sql) === TRUE) {

        // Recipe data from POST
        $recipe_id = $_POST['recipe_id'];
        $title = $_POST['title'];
        $time_needs = $_POST['time_needs'];
        $cuisine_id = $_POST['cuisine_id'];
        $likes_count = 0;  // default to zero for new recipe

        // Insert recipe linked to the cuisine inserted
        $sql2 = "INSERT INTO recipes (recipe_id, title, time_needs, cuisine_id, likes_count, )
                 VALUES ('$recipe_id', '$title', '$time_needs', '$cuisine_id', '$likes_count')";

        if ($conn->query($sql2) === TRUE) {
            echo "<script>alert('Checkout complete');</script>";
            echo "<script>window.setTimeout(function(){ window.location.href = 'index.htm'; }, 1000);</script>";
        } else {
            echo "Error inserting recipe: " . $conn->error;
        }

    } else {
        echo "Error inserting cuisine: " . $conn->error;
    }

    $conn->close();
?>
